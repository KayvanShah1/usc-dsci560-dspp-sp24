#!/usr/bin/env python
# coding: utf-8

# In[55]:


import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf


# In[56]:


columns = ["Date", "Open", "High", "Low", "Close", "Adj Close", "Volume"]
data=pd.read_csv('ANDANIENT.NS.csv',names=columns, header=None, skiprows=1, parse_dates=["Date"])
data


# In[57]:


data.isnull().sum()/len(data)


# In[58]:


plt.figure(figsize=(20,10))
sns.set_style('darkgrid')
plt.xlabel('Date')
plt.ylabel('Close Price')
plt.title('ANDANIENT stock market closing price')
plt.plot(data["Close"])


# In[59]:


from statsmodels.tsa.stattools import adfuller 
def test_adf(timeseries):
    moving_average=timeseries.rolling(12).mean()
    moving_std=timeseries.rolling(12).std()
    plt.figure(figsize=(20,10))
    plt.plot(timeseries, color='blue', label='Original')
    plt.plot(moving_average, color='red', label='Rolling Mean')
    plt.plot(moving_std, color='black', label="Rolling Std")
    plt.legend(loc='best')
    plt.title('Rolling Mean and Standard Deviation')
    plt.show(block=False)
    adft=adfuller(timeseries, autolag="AIC")
    output=pd.Series (adft[0:4], index=['Test Statistics', 'p-value', 'No. of lags used', 'Number of observations used'])
    for key, value in adft[4].items():
        output['Critical value (%s) '%key]=value
    print(output)
test_adf(data['Close'])


# In[60]:


from statsmodels.tsa.seasonal import seasonal_decompose
result=seasonal_decompose(data["Close"],model='multiplicative', period=30)
fig=plt.figure() 
fig=result.plot()
fig.set_size_inches(16,9)


# In[61]:


import numpy as np
from pylab import rcParams 
rcParams['figure.figsize']= 20, 10
data_log=np.log(data["Close"])
moving_average=data_log.rolling(10).mean()
std_dev=data_log.rolling(12).std()
plt.legend(loc='best')
plt.title('Moving Average')
plt.plot(std_dev, color ="black", label= "Standard Deviation")
plt.plot(moving_average, color="red", label = "Mean")
plt.legend()
plt.show()


# In[62]:


data_log_mean=data_log-moving_average
data_log_mean.dropna(inplace=True)
test_adf(data_log_mean)


# In[63]:


train_data, test_data=data_log[:int(len(data_log)*0.90)], data_log[int (len(data_log_mean)*0.90):]
plt.figure(figsize=(20,10))
plt.xlabel("Dates")
plt.ylabel('Closing Prices')
plt.plot(data_log, 'green', label="Train data")
plt.plot(test_data, 'blue', label='Test data')
plt.legend()


# In[64]:


# Autocorrelation Plot
plt.figure(figsize=(14, 7))
plot_acf(data['Close'], lags=30, title='Autocorrelation Plot')
plt.xlabel('Lags')
plt.ylabel('ACF')
plt.show()

# Partial Autocorrelation Plot
plt.figure(figsize=(14, 7))
plot_pacf(data['Close'], lags=30, title='Partial Autocorrelation Plot')
plt.xlabel('Lags')
plt.ylabel('PACF')
plt.show()


# In[65]:


from statsmodels.tsa.arima_model import ARIMA
import pmdarima as pm
model = pm.auto_arima(train_data, start_p=0, start_q=0,
test='adf',
max_p=10, 
max_q=10,
m=1,
d=None,
seasonal=False,
start_P=0,
D=0,
trace=True,
error_action='ignore',
suppress_warnings=True,
stepwise=True)


# print model summary
print(model.summary())


# In[66]:


from statsmodels.tsa.arima.model import ARIMA
model = ARIMA(train_data, order=(4,1,6))
fitted = model.fit()
test_data.shape


# In[67]:


# Forecasting
steps = len(test_data) 
fc = fitted.forecast(steps=steps)

fc_series = pd.Series(fc, index=test_data.index)
conf_int = fitted.get_forecast(steps=steps, alpha=0.05).conf_int()
lower_series = pd.Series(conf_int.iloc[:, 0].values, index=test_data.index)
upper_series = pd.Series(conf_int.iloc[:, 1].values, index=test_data.index)

# Plotting
plt.figure(figsize=(12, 5), dpi=100)
plt.plot(train_data, label='Training')
plt.plot(test_data, color='blue', label='Actual Stock Price')
plt.plot(fc_series, color='orange', label='Predicted Stock Price')
plt.fill_between(lower_series.index, lower_series, upper_series, color='k', alpha=.05)
plt.title('ANDANIENT Stock Price Prediction')
plt.xlabel('Time')
plt.ylabel('Actual Stock Price')
plt.legend(loc='upper left', fontsize=8)
plt.show()


# In[68]:


import math
from sklearn.metrics import mean_squared_error, mean_absolute_error 
mse = mean_squared_error(test_data, fc)
print('MSE: '+str(mse))
mae = mean_absolute_error(test_data, fc)
print('MAE: '+str(mae))
rmse = math.sqrt(mean_squared_error(test_data, fc)) 
print('RMSE: '+str(rmse))
mape = np.mean(np.abs(fc - test_data)/np.abs(test_data)) 
print('MAPE: '+str(mape))


# In[ ]:





# In[ ]:





# In[ ]:





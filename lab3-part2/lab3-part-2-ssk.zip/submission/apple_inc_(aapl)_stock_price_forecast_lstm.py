# -*- coding: utf-8 -*-


# !pip install --upgrade scikit-learn

from datetime import datetime,timedelta
import warnings
import sys

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

import tensorflow as tf
from keras.layers import LSTM, Dense, Dropout
from keras.models import Sequential

import statsmodels.api as sm
from statsmodels.tsa.stattools import pacf, acf
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf

from sklearn.metrics import root_mean_squared_error as rmse
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import MinMaxScaler

import yfinance as yf
from pandas_datareader import data as pdr

from tqdm import tqdm
yf.pdr_override()

warnings.filterwarnings("ignore")

"""# Data Extraction"""

def get_ticker_data(ticker_code: str, start_date=None, end_date=datetime.today()):
    if start_date is not None:
        data = pdr.get_data_yahoo(ticker_code, start=start_date, end=end_date)
    else:
        data = pdr.get_data_yahoo(ticker_code, end=end_date)
    return data


def clean_ticker_data(df):
    df = df.reset_index()
    df.columns = [col.lower().replace(" ", "_") for col in df.columns]
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    df = df.sort_values(by="date", ascending=True)
    df.rename(columns={"date": "datetime"}, inplace=True)
    return df


def resample(df):
    df = df.set_index("datetime")
    df = df.resample("D").asfreq()
    return df


def basic_preprocess(df):
    df = df.astype("float64")
    df = df.interpolate(method="time")
    df = df.fillna("bfill")
    return df.reset_index()


def prepare_ticker_data(ticker_code: str, start_date=None, end_date=datetime.today()):
    df = get_ticker_data(ticker_code, start_date=start_date, end_date=end_date)
    df = clean_ticker_data(df)
    df = resample(df)
    df = basic_preprocess(df)
    return df

ticker = sys.argv[1]
stock_data = prepare_ticker_data(ticker, start_date="2004-06-01")
stock_data.to_csv("AAPL_daily.csv", index=False)

aapl_daily = pd.read_csv("AAPL_daily.csv")
aapl_daily

"""# Data Processing"""

# Calculate MACD
def calculate_macd(df, short_window=12, long_window=26, signal_window=9):
    exp1 = df["close"].ewm(span=short_window, adjust=False).mean()
    exp2 = df["close"].ewm(span=long_window, adjust=False).mean()
    macd = exp1 - exp2
    signal = macd.ewm(span=signal_window, adjust=False).mean()
    df["macd"] = macd
    df["macd_signal"] = signal
    return df

# Calculate RSI
def calculate_rsi(df, window=14):
    delta = df["close"].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=window).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=window).mean()
    rs = gain / loss
    df["rsi"] = 100 - (100 / (1 + rs))
    return df

# Function to find crossover points and label them as "Buy" or "Sell"
def find_crossover_points(df):
    crossover_points = []
    prev_crossover = None

    for i in range(1, len(df)):
        if df["macd"][i] > df["macd_signal"][i] and df["macd"][i - 1] <= df["macd_signal"][i - 1]:
            crossover_points.append(("Buy", df["datetime"][i]))
            prev_crossover = "Buy"
        elif df["macd"][i] < df["macd_signal"][i] and df["macd"][i - 1] >= df["macd_signal"][i - 1]:
            crossover_points.append(("Sell", df["datetime"][i]))
            prev_crossover = "Sell"
        else:
            if prev_crossover is not None:
                crossover_points.append((prev_crossover, df["datetime"][i]))

    return crossover_points


def find_crossover_points_mod(df):
    crossover_points = ["No Action"]
    prev_crossover = None

    for i in range(1, len(df)):
        if (df["macd"][i] > df["macd_signal"][i] and df["macd"][i - 1] <= df["macd_signal"][i - 1]) or \
           (df["macd"][i] < df["macd_signal"][i] and df["macd"][i - 1] >= df["macd_signal"][i - 1]):
            crossover_points.append("Buy" if df["macd"][i] > df["macd_signal"][i] else "Sell")
            prev_crossover = "Buy" if df["macd"][i] > df["macd_signal"][i] else "Sell"
        else:
            if prev_crossover is not None:
                crossover_points.append(prev_crossover)
            else:
                crossover_points.append("No Action")

    return crossover_points

df = pd.read_csv(
    "AAPL_daily.csv",
    usecols=["datetime", "close"]
)
df["datetime"] = pd.to_datetime(df["datetime"], errors="coerce")
df["day_of_week"] = df["datetime"].dt.dayofweek
df["month"] = df["datetime"].dt.month
df["year"] = df["datetime"].dt.year
df["day_of_year"] = df["datetime"].dt.dayofyear
df["quarter"] = df["datetime"].dt.quarter

df = calculate_macd(df, short_window=12, long_window=26, signal_window=10)
df = calculate_rsi(df)
df.dropna(inplace=True)



"""## Scaling"""

features_to_be_scaled = ["day_of_week", "month", "year", "day_of_year", "quarter", "macd", "macd_signal", "rsi"]
predicate_scaler = ["close"]

# Feature scaler
feature_scaler = MinMaxScaler()
scaled_features = feature_scaler.fit_transform(df[features_to_be_scaled])
df[[f"scaled_{i}" for i in features_to_be_scaled]] = scaled_features

# Prediction scaler
prediction_scaler = MinMaxScaler()
scaled_predictions = prediction_scaler.fit_transform(df[predicate_scaler])
df[[f"scaled_{i}" for i in predicate_scaler]] = scaled_predictions



"""## Subset"""

# Select a subset of data for plotting (for example, first 100 data points)
subset_df = df.tail(500).reset_index()
subset_df.drop(columns=["index"], inplace=True)

subset_df

# Plotting
plt.figure(figsize=(14, 10))

# Closing price subplot
plt.subplot(3, 1, 1)
plt.plot(subset_df["datetime"], subset_df["scaled_close"], label="Scaled Close", color="blue")
plt.title("Scaled AAPL Daily Closing Price")
plt.xlabel("Date")
plt.ylabel("Scaled Value")
plt.legend()
plt.grid(True)

# MACD subplot
plt.subplot(3, 1, 2)
plt.plot(subset_df["datetime"], subset_df["scaled_close"], label="Scaled Close", color="blue")
plt.plot(subset_df["datetime"], subset_df["scaled_macd"], label="Scaled MACD", color="red", alpha=0.75)
plt.plot(subset_df["datetime"], subset_df["scaled_macd_signal"], label="Scaled Signal Line", color="green", alpha=0.75)
plt.title("Scaled MACD and Signal Line")
plt.xlabel("Date")
plt.ylabel("Scaled Value")
plt.legend()
plt.grid(True)

# RSI subplot
plt.subplot(3, 1, 3)
plt.plot(subset_df["datetime"], subset_df["scaled_close"], label="Scaled Close", color="blue")
plt.plot(subset_df["datetime"], subset_df["scaled_rsi"], label="Scaled RSI", color="purple", alpha=0.75)
plt.title("Scaled RSI")
plt.xlabel("Date")
plt.ylabel("Scaled Value")
plt.legend()
plt.grid(True)

plt.tight_layout()
plt.show()

"""## Correlation Analysis

Based on the correlation matrix and your specific objectives, you might consider the following features:

1. **Close Price (`close`)**: This is the target variable you want to predict. It has moderate correlations with `year` and `macd_signal`, indicating their potential predictive power.

2. **MACD and MACD Signal (`macd`, `macd_signal`)**: These technical indicators have moderate correlations with the close price, suggesting they might be useful predictors. Additionally, they show a strong correlation with each other, which can be helpful for feature engineering or model selection.

3. **Year (`year`)**: The year has a moderate correlation with the close price, indicating a potential trend over time. Including this feature might capture long-term trends in the stock price.

4. **RSI (`rsi`)**: The Relative Strength Index has a weak positive correlation with the close price and moderate correlations with MACD and MACD Signal. While its correlation is weaker compared to other features, it might still provide valuable information for prediction.

5. **Day of Week (`day_of_week`)** and **Month (`month`)**: These date-related features have very weak correlations with the close price. However, they might still capture seasonal patterns or behavioral trends in trading, so it could be worth experimenting with them.

You may start with these features and iteratively refine your model based on performance metrics such as accuracy, precision, recall, or Mean Squared Error (MSE). Additionally, consider incorporating domain knowledge or experimenting with feature engineering techniques to further improve predictive performance.
"""

# Correlation analysis
correlation_matrix = df[["close", "day_of_week", "month", "year", "day_of_year", "quarter", "macd", "macd_signal", "rsi"]].corr()

# Generate a mask for the upper triangle
mask = np.triu(np.ones_like(correlation_matrix, dtype=bool))

# Plotting
plt.figure(figsize=(10, 8))
sns.heatmap(correlation_matrix, cmap='coolwarm', annot=True, fmt=".2f", square=True)
plt.title('Correlation Matrix of Features')
plt.xticks(range(len(correlation_matrix.columns)), correlation_matrix.columns, rotation=45)
plt.yticks(range(len(correlation_matrix.columns)), correlation_matrix.columns, rotation=45)
plt.show()

"""
1. **Autocorrelation Function (ACF)**:
   - The ACF at lag 0 is always 1 because it represents the correlation of the series with itself.
   - Look for significant spikes in the ACF plot. Significant spikes are those that extend beyond the blue shaded region, indicating potential correlations.
   - In your ACF values, you can see that the autocorrelation remains high (close to 1) for many lags, which suggests strong autocorrelation. However, it starts to decrease gradually.
   - Significant autocorrelation is observed up to lag 2. After that, it starts to decrease, but there are still some significant values up to lag 10.
   - You can consider using lags 1 and 2 as they have high autocorrelation values. Beyond that, you might consider lags up to 10 if you want to capture more autocorrelation.

2. **Partial Autocorrelation Function (PACF)**:
   - The PACF at lag 0 is always 1 because it represents the correlation of the series with itself.
   - Look for significant spikes in the PACF plot. Similar to the ACF plot, significant spikes are those that extend beyond the blue shaded region.
   - In your PACF values, you can see that the partial autocorrelation remains high (close to 1) for the first few lags, and then it starts to drop off.
   - Significant partial autocorrelation is observed up to lag 2. After that, it becomes close to zero, indicating that the autocorrelation is being explained by the previous lags.
   - Therefore, you can consider using lags 1 and 2 based on the PACF.

Based on the analysis of both ACF and PACF, you can consider using lags 1 and 2 for modeling the autocorrelation in your data. However, depending on your specific analysis and model requirements, you may choose to include more lags."""

# # Compute ACF and PACF values
# acf_values = acf(close_series, nlags=30)
# pacf_values = pacf(close_series, nlags=30)

# list(zip(acf_values, pacf_values))

# Prepare Data
close_series = df["close"]

# Compute ACF and PACF
plt.figure(figsize=(12, 6))
plt.subplot(2, 1, 1)
plot_acf(close_series, lags=30, ax=plt.gca(), title="Autocorrelation Function (ACF)")
plt.subplot(2, 1, 2)
plot_pacf(close_series, lags=30, ax=plt.gca(), title="Partial Autocorrelation Function (PACF)")
plt.tight_layout()
plt.show()

"""## Lag Analysis"""

# Add lag features up to 5 lags
def add_lags(df, n):
    for i in range(1, n+1):
        df[f'lag_{i}_scaled_close'] = df['scaled_close'].shift(i)
    df.dropna(inplace=True)
    return df

#Drop NaN values
lagged_df = df.copy(deep=True)
lagged_df = add_lags(lagged_df, 5)

sel_cols = [
    'datetime',
    'scaled_day_of_week', 'scaled_month', 'scaled_year', 'scaled_day_of_year', 'scaled_quarter',
    'scaled_macd', 'scaled_macd_signal', 'scaled_rsi',
    'scaled_close',
    'lag_1_scaled_close', 'lag_2_scaled_close', 'lag_3_scaled_close', 'lag_4_scaled_close', 'lag_5_scaled_close'
]

lagged_df = lagged_df.loc[:, sel_cols]
lagged_df

# Define the ratio for train-test split
train_ratio = 0.9
test_ratio = 1 - train_ratio

# Calculate the index for splitting the data
split_index = int(train_ratio * len(lagged_df))

# Split the data into train and test sets
train_data = lagged_df.iloc[:split_index]
test_data = lagged_df.iloc[split_index:]

# Separate the features (X) and target (y) variables
X_train = train_data.drop(columns=['datetime', 'scaled_close'])
y_train = train_data['scaled_close']

X_test = test_data.drop(columns=['datetime', 'scaled_close'])
y_test = test_data['scaled_close']

# Plot train and test data
plt.figure(figsize=(20, 7))
plt.plot(train_data['datetime'], train_data['scaled_close'], label='Train', color='blue')
plt.plot(test_data['datetime'], test_data['scaled_close'], label='Test', color='red')

plt.title('Train and Test Data')
plt.xlabel('Date')
plt.ylabel('Scaled Close')
plt.legend()
plt.grid(True)

plt.show()

X_train = X_train.values.reshape(X_train.shape[0], 1, X_train.shape[1])
X_test = X_test.values.reshape(X_test.shape[0], 1, X_test.shape[1])

# Define the LSTM model
model = Sequential([
    LSTM(10, input_shape=(X_train.shape[1], X_train.shape[2])),
    Dense(1)
])

# Compile the model
model.compile(optimizer='adam', loss='mse')

model.summary()

model.fit(X_train, y_train, epochs=10, batch_size=32, verbose=1)

# 6. Evaluate the Model
y_pred = model.predict(X_test)
mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)
print("Mean Squared Error:", mse)
print("Root Mean Squared Error:", rmse)

# Calculate residuals
residuals = y_test - y_pred.reshape(-1)

# Compute standard deviation of residuals
std_dev = np.std(residuals)

# Calculate confidence intervals
confidence_interval = 1.96 * std_dev  # 95% confidence interval

# Plotting
plt.figure(figsize=(14, 7))

# Plot training data
plt.plot(train_data['datetime'], train_data['scaled_close'], label='Train Data', color='blue')

# Plot test data
plt.plot(test_data['datetime'], test_data['scaled_close'], label='Test Data', color='red')

# Plot predicted values
plt.plot(test_data['datetime'], y_pred, label='Predicted', color='green')

# Compute upper and lower bounds for confidence interval
upper_bound = y_pred + 1.96 * std_dev
lower_bound = y_pred - 1.96 * std_dev

# # Plot confidence interval
plt.fill_between(test_data['datetime'], upper_bound.flatten(), lower_bound.flatten(), color='gray', alpha=0.3, label='Confidence Interval')

# Set x-axis limits
plt.xlim(pd.Timestamp('2020-07-01'), pd.Timestamp('2024-03-31'))
# Set y-axis limits
plt.ylim(0.5, 1.1)

# Add labels and title
plt.xlabel('Date')
plt.ylabel('Scaled Close')
plt.title('Train and Test Data with Predictions and Confidence Interval')
plt.legend()
plt.grid(True)

# Show plot
plt.show()

"""#Predictions for the Next 14 Days"""

df = pd.read_csv(
    "AAPL_daily.csv",
    usecols=["datetime", "close"]
)
df["datetime"] = pd.to_datetime(df["datetime"], errors="coerce")
df["day_of_week"] = df["datetime"].dt.dayofweek
df["month"] = df["datetime"].dt.month
df["year"] = df["datetime"].dt.year
df["day_of_year"] = df["datetime"].dt.dayofyear
df["quarter"] = df["datetime"].dt.quarter

df = calculate_macd(df, short_window=12, long_window=26, signal_window=10)
df = calculate_rsi(df)
df.dropna(inplace=True)



"""##Adding New Dates"""

def add_lags2(df, n):
    for i in range(1, n+1):
        df[f'lag_{i}_scaled_close'] = df['scaled_close'].shift(i)
    # df.dropna(inplace=True)
    return df

def driver(new_df):
  new_df = calculate_macd(new_df, short_window=12, long_window=26, signal_window=10)
  new_df = calculate_rsi(new_df)

  features_to_be_scaled = ["day_of_week", "month", "year", "day_of_year", "quarter", "macd", "macd_signal", "rsi"]
  predicate_scaler = ["close"]

  feature_scaler = MinMaxScaler()
  scaled_features = feature_scaler.fit_transform(new_df[features_to_be_scaled])
  new_df[[f"scaled_{i}" for i in features_to_be_scaled]] = scaled_features

  # Prediction scaler
  prediction_scaler = MinMaxScaler()
  scaled_predictions = prediction_scaler.fit_transform(new_df[predicate_scaler])
  new_df[[f"scaled_{i}" for i in predicate_scaler]] = scaled_predictions
  preprocessed_df = add_lags2(new_df,5)

  new_df = preprocessed_df[['scaled_day_of_week', 'scaled_month','scaled_year', 'scaled_day_of_year', 'scaled_quarter',
                   'scaled_macd','scaled_macd_signal', 'scaled_rsi','lag_1_scaled_close', 'lag_2_scaled_close',
                   'lag_3_scaled_close','lag_4_scaled_close', 'lag_5_scaled_close','scaled_close']]

  preprocessed_df.drop(new_df.columns,axis=1,inplace=True)

  X_test = new_df.iloc[-1,:]
  X_test.drop(["scaled_close"],inplace=True)
  new_df.dropna(inplace=True)
  y_train = new_df["scaled_close"]
  X_train = new_df.drop(["scaled_close"],axis=1)

  X_test = X_test.values.reshape(1,X_test.shape[0])
  X_train = X_train.values.reshape(X_train.shape[0], 1, X_train.shape[1])
  X_test = X_test.reshape(X_test.shape[0], 1, X_test.shape[1])
  model.fit(X_train,y_train,epochs=10,batch_size=32,verbose=1)

  pred = model.predict(X_test)
  pred = prediction_scaler.inverse_transform(pred)
  preprocessed_df["close"].iloc[-1] = pred[0][0]
  return preprocessed_df

start_date = datetime.strptime("2024-2-06","%Y-%m-%d")

for i in tqdm(range(1,15)):
  new_row = {}
  next_date = start_date+timedelta(days=i)
  new_row["datetime"] = next_date.date()
  new_row["day_of_week"] = next_date.weekday()
  new_row["month"] = next_date.month
  new_row["year"] = next_date.year
  period = pd.Period(next_date,freq="D")
  new_row["day_of_year"] = period.day_of_year
  new_row["quarter"] = (new_row["month"]-1)//3+1
  new_row["macd"] = np.nan
  new_row["macd_signal"] = np.nan
  new_row["rsi"] = np.nan
  new_row["close"] = np.nan
  new_df = df.append(new_row,ignore_index=True)
  result_df = driver(new_df)
  new_row = result_df.iloc[-1,:]
  df = df.append(new_row,ignore_index=True)

print(df)
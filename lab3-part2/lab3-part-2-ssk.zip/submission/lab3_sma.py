#!/usr/bin/env python
# coding: utf-8

# In[16]:


import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
data=['ANDANIENT.NS.csv','META.csv','AAPL.csv']
stocks=['ANDANIENT','META','APPLE']


# In[33]:


def calculate_sma(dataframe, window):
    return dataframe['Close'].rolling(window=window).mean()

def calculate_rsi(dataframe, window):
    delta = dataframe['Close'].diff()
    up = delta.clip(lower=0)
    down = -1 * delta.clip(upper=0)
    ma_up = up.rolling(window=window).mean()
    ma_down = down.rolling(window=window).mean()
    
    rsi = 100 - (100 / (1 + ma_up / ma_down))
    return rsi
def generate_signals(dataframe):
    dataframe['buy_signal'] = 0
    dataframe['sell_signal'] = 0
    position = None 
    
    for index, row in dataframe.iterrows():
        if row['sma_short'] > row['sma_long'] and row['rsi'] < 40:
            if position != 'long':
                dataframe.at[index, 'buy_signal'] = 1
                position = 'long'
        elif row['sma_short'] < row['sma_long'] or row['rsi'] > 60:
            if position == 'long':
                dataframe.at[index, 'sell_signal'] = -1
                position = None
    
    return dataframe
def calculate_annualized_returns(dataframe):
    start_date = dataframe.index.min()
    end_date = dataframe.index.max()
    investment_period_years = (end_date - start_date).days / 365
    
    total_return = (dataframe['Close'].iloc[-1] - dataframe['Close'].iloc[0]) / dataframe['Close'].iloc[0]
    
    annualized_return = ((1 + total_return) ** (1 / investment_period_years)) - 1
    
    return annualized_return
def calculate_sharpe_ratio(dataframe, risk_free_rate=0.0001):
    daily_returns = dataframe['Close'].pct_change()
    avg_daily_return = daily_returns.mean()
    std_dev_daily_return = daily_returns.std()
    
    annualized_avg_return = avg_daily_return * 365 
    annualized_std_dev = std_dev_daily_return * np.sqrt(365)
    
    sharpe_ratio = (annualized_avg_return - risk_free_rate) / annualized_std_dev
    
    return sharpe_ratio

def mock_trading(dataframe, initial_fund):
    cash = initial_fund
    shares_held = 0
    portfolio_value = []
    transaction_log = []

    for index, row in dataframe.iterrows():
        if row['buy_signal'] == 1:
            shares_to_buy = cash // row['Close']
            if shares_to_buy > 0:
                cash -= shares_to_buy * row['Close']
                shares_held += shares_to_buy
                transaction_log.append((index, 'BUY', shares_to_buy, row['Close']))
        elif row['sell_signal'] == -1 and shares_held > 0:
            cash += shares_held * row['Close']
            transaction_log.append((index, 'SELL', shares_held, row['Close']))
            shares_held = 0
        portfolio_value.append(cash + shares_held * row['Close'])
    dataframe['portfolio_value'] = portfolio_value
    transaction_df = pd.DataFrame(transaction_log, columns=['Date', 'Action', 'Shares', 'Price'])

    return dataframe, transaction_df


# In[34]:


portfolios={}
Annual_Returns={}
Sharp_Ratio={}
overall_portfolio=0
overall_profit=0
for index, (d, s) in enumerate(zip(data, stocks)):
    df= pd.read_csv(d)
    print(s,"Data")
    df['date'] = pd.to_datetime(df['Date'])
    df.set_index('date', inplace=True)
    df.sort_index(inplace=True)
    sma_short_window = 50
    sma_long_window =200
    rsi_window = 20
    df['sma_short'] = calculate_sma(df, sma_short_window)
    df['sma_long'] = calculate_sma(df, sma_long_window)
    df['rsi'] = calculate_rsi(df, rsi_window)
    df = generate_signals(df)
    initial_investment = 10000  
    df, transaction_log_df = mock_trading(df, initial_investment)
    plt.figure(figsize=(14,7))
    plt.plot(df.index, df['Close'], label='Close Price', alpha=0.7)
    plt.scatter(df[df['buy_signal'] == 1].index, df[df['buy_signal'] == 1]['Close'], marker='^', color='g', label='Buy Signal', lw=2)
    plt.scatter(df[df['sell_signal'] == -1].index, df[df['sell_signal'] == -1]['Close'], marker='v', color='r', label='Sell Signal', lw=2)
    plt.title('Buy and Sell Signals')
    plt.xlabel('Date')
    plt.ylabel('Price')
    plt.legend()
    plt.show()
    print(transaction_log_df)
    final_portfolio_value = df['portfolio_value'].iloc[-1]
    print(f"\nFinal Portfolio Value for {s}: ${final_portfolio_value:.2f}\n")
    portfolios[s] = final_portfolio_value
    annualized_return = calculate_annualized_returns(df)
    print(f"Annualized Return for {s}: {annualized_return:.2%}")
    Annual_Returns[s]=annualized_return
    overall_portfolio += final_portfolio_value
    sharpe_ratio = calculate_sharpe_ratio(df)
    print(f"Sharpe Ratio for {s}: {sharpe_ratio:.2f}")
    Sharp_Ratio[s]=sharpe_ratio
print("PORTFOLIO VALUES")
print(portfolios)
print("Overall Portfolio Value",overall_portfolio)
profit={}
for k,v in portfolios.items():
    profit[k]=v-10000
    overall_profit+=profit[k]
print("PROFIT VALUES")
print(profit)
print("Overall Profit:",overall_profit)
print("ANNUALIZED RETURNS")
print(Annual_Returns)
print("Sharp Ratio")
print(Sharp_Ratio)


# In[ ]:





# In[ ]:





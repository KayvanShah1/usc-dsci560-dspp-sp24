import pandas as pd
import os

os.system('kaggle datasets download kreeshrajani/3k-conversations-dataset-for-chatbot -f Conversation.csv')
print('Download complete')
df = pd.read_csv('/home/shreyanshbardia/shreyansh_3739756887/Lab 2/Conversation.csv')
print('First 5 rows:')
print(df.head())
print('dataset dimensions:',df.shape)
print('dataset size:',df.size)
print('Missing values:')
print(df.isna().sum())

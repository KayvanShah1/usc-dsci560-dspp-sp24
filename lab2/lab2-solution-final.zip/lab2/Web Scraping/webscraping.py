from selenium import webdriver
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import csv
service=Service(executable_path='/snap/bin/geckodriver')
driver=webdriver.Firefox(service=service)
driver.get('https://machinelearningmastery.com/linear-regression-for-machine-learning/')
time.sleep(3)
texts=driver.find_elements(By.TAG_NAME,'p')
print("Number of text elements:",len(texts))
print("First text element:",texts[0].text)

output_file='../output.txt'
with open(output_file,'w',encoding='utf-8') as file:
	for t in texts:
		file.write(t.text+'\n')
driver.quit()

# Prompt the user for input
user_name = input("Enter your name: ")

# Display the greeting in the terminal
print(f"Hello, {user_name}!")
